﻿/* Grading ID:A1469
 Program 1
 Due:9/26/2017
 Course: 199-01
 This application that will calculate the number of gallons of paint needed to paint the walls in a room*/
 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1
{
    class Program
    {
        static void Main(string[] args)
        {
            double lengthOfWalls; // Declare a variable for length of walls
            double heigthOfWalls; // Declare a variable for heigth of walls
            int numberOfDoors; // Declare a variable for number of doors
            int numberOfWindows; // Declare a variable for the number of windows
            double numberOfCoats; // Declare a variable for the number of coats
            string lengthOfWallsAsAString; // Declare a string for lenght of walls
            string heigthOfWallsAsAString; // Declare a string for height of walls
            string numberOfDoorsAsAString; // Declare a string for number of doors
            string numberOfWindowsAsAString; //Declare a string for number of windows
            string numberOfCoatsAsAString; //Declare a string for the number of coats
            const double DOOR_VALUE = 20; // Declare a constant for door value
            const double WINDOW_VALUE = 15; // Declare a constant for window value
            const double NUMBER_OF_SQUARE_FEET = 350; // Declare a constant for the number of square feet
            double gallonsToBuy; // Declare a variable for gallons of paint
            double gallonsToPaint; // Declare a variable for gallons to paint
            double surfaceArea;// Declares a variable for surface area


            Console.WriteLine("Welcome to the Handy-Dandy Paint Estimator");

            Console.WriteLine("");
        
            

            Console.Write("Enter the total length of all walls (in feet):  ");
            lengthOfWallsAsAString = Console.ReadLine();
            lengthOfWalls = Double.Parse(lengthOfWallsAsAString);

            Console.Write("Enter the height of the walls (in feet):  ");
            heigthOfWallsAsAString = Console.ReadLine();
            heigthOfWalls = Double.Parse(heigthOfWallsAsAString);

            Console.Write("Enter the number of doors (non-neg int):  " );
            numberOfDoorsAsAString = Console.ReadLine();
            numberOfDoors = Int32.Parse(numberOfDoorsAsAString);

            Console.Write("Enter the number of windows (non-neg int): " );
            numberOfWindowsAsAString = Console.ReadLine();
            numberOfWindows = Int32.Parse(numberOfWindowsAsAString);

            Console.Write("Enter the number of coats of paint (non-neg int):  " );
            numberOfCoatsAsAString = Console.ReadLine();
            numberOfCoats = Int32.Parse(numberOfCoatsAsAString);

            Console.WriteLine("");

            surfaceArea = lengthOfWalls * heigthOfWalls - (numberOfDoors * DOOR_VALUE) - (numberOfWindows * WINDOW_VALUE);

            gallonsToPaint = ((surfaceArea * numberOfCoats) / NUMBER_OF_SQUARE_FEET);

            Console.WriteLine("You need a minimum of {0:F1} gallons of paint",
                gallonsToPaint);

            gallonsToBuy = (int)Math.Ceiling(gallonsToPaint);
            Console.WriteLine("You'll need to buy {0} gallons, though",
                gallonsToBuy);
            
        

            
            


                
            

            
                
        



        
       

        }
    }
}
