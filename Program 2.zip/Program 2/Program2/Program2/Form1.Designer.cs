﻿namespace Program2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.springRegistrationLabel = new System.Windows.Forms.Label();
            this.lastNameInitialLabel = new System.Windows.Forms.Label();
            this.lastNameInitialTextBox = new System.Windows.Forms.TextBox();
            this.freshmanButton = new System.Windows.Forms.RadioButton();
            this.classStandingLabel = new System.Windows.Forms.Label();
            this.sophomoreButton = new System.Windows.Forms.RadioButton();
            this.juniorButton = new System.Windows.Forms.RadioButton();
            this.seniorButton = new System.Windows.Forms.RadioButton();
            this.registartionButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // springRegistrationLabel
            // 
            this.springRegistrationLabel.AutoSize = true;
            this.springRegistrationLabel.Location = new System.Drawing.Point(89, 9);
            this.springRegistrationLabel.Name = "springRegistrationLabel";
            this.springRegistrationLabel.Size = new System.Drawing.Size(240, 20);
            this.springRegistrationLabel.TabIndex = 0;
            this.springRegistrationLabel.Text = " Spring 2018 Priority Registration";
            // 
            // lastNameInitialLabel
            // 
            this.lastNameInitialLabel.AutoSize = true;
            this.lastNameInitialLabel.Location = new System.Drawing.Point(12, 58);
            this.lastNameInitialLabel.Name = "lastNameInitialLabel";
            this.lastNameInitialLabel.Size = new System.Drawing.Size(205, 20);
            this.lastNameInitialLabel.TabIndex = 1;
            this.lastNameInitialLabel.Text = "Enter first inital of last name";
            // 
            // lastNameInitialTextBox
            // 
            this.lastNameInitialTextBox.Location = new System.Drawing.Point(229, 58);
            this.lastNameInitialTextBox.Name = "lastNameInitialTextBox";
            this.lastNameInitialTextBox.Size = new System.Drawing.Size(100, 26);
            this.lastNameInitialTextBox.TabIndex = 2;
            // 
            // freshmanButton
            // 
            this.freshmanButton.AutoSize = true;
            this.freshmanButton.Location = new System.Drawing.Point(16, 162);
            this.freshmanButton.Name = "freshmanButton";
            this.freshmanButton.Size = new System.Drawing.Size(106, 24);
            this.freshmanButton.TabIndex = 3;
            this.freshmanButton.TabStop = true;
            this.freshmanButton.Text = "Freshman";
            this.freshmanButton.UseVisualStyleBackColor = true;
            
            // 
            // classStandingLabel
            // 
            this.classStandingLabel.AutoSize = true;
            this.classStandingLabel.Location = new System.Drawing.Point(12, 110);
            this.classStandingLabel.Name = "classStandingLabel";
            this.classStandingLabel.Size = new System.Drawing.Size(120, 20);
            this.classStandingLabel.TabIndex = 4;
            this.classStandingLabel.Text = "Class Standing:";
            // 
            // sophomoreButton
            // 
            this.sophomoreButton.AutoSize = true;
            this.sophomoreButton.Location = new System.Drawing.Point(16, 212);
            this.sophomoreButton.Name = "sophomoreButton";
            this.sophomoreButton.Size = new System.Drawing.Size(117, 24);
            this.sophomoreButton.TabIndex = 5;
            this.sophomoreButton.TabStop = true;
            this.sophomoreButton.Text = "Sophomore";
            this.sophomoreButton.UseVisualStyleBackColor = true;
            // 
            // juniorButton
            // 
            this.juniorButton.AutoSize = true;
            this.juniorButton.Location = new System.Drawing.Point(16, 261);
            this.juniorButton.Name = "juniorButton";
            this.juniorButton.Size = new System.Drawing.Size(77, 24);
            this.juniorButton.TabIndex = 6;
            this.juniorButton.TabStop = true;
            this.juniorButton.Text = "Junior";
            this.juniorButton.UseVisualStyleBackColor = true;
            // 
            // seniorButton
            // 
            this.seniorButton.AutoSize = true;
            this.seniorButton.Location = new System.Drawing.Point(16, 302);
            this.seniorButton.Name = "seniorButton";
            this.seniorButton.Size = new System.Drawing.Size(80, 24);
            this.seniorButton.TabIndex = 7;
            this.seniorButton.TabStop = true;
            this.seniorButton.Text = "Senior";
            this.seniorButton.UseVisualStyleBackColor = true;
            // 
            // registartionButton
            // 
            this.registartionButton.Location = new System.Drawing.Point(195, 299);
            this.registartionButton.Name = "registartionButton";
            this.registartionButton.Size = new System.Drawing.Size(124, 65);
            this.registartionButton.TabIndex = 8;
            this.registartionButton.Text = "Click for Registation Date/Time";
            this.registartionButton.UseVisualStyleBackColor = true;
            this.registartionButton.Click += new System.EventHandler(this.registartionButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 376);
            this.Controls.Add(this.registartionButton);
            this.Controls.Add(this.seniorButton);
            this.Controls.Add(this.juniorButton);
            this.Controls.Add(this.sophomoreButton);
            this.Controls.Add(this.classStandingLabel);
            this.Controls.Add(this.freshmanButton);
            this.Controls.Add(this.lastNameInitialTextBox);
            this.Controls.Add(this.lastNameInitialLabel);
            this.Controls.Add(this.springRegistrationLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label springRegistrationLabel;
        private System.Windows.Forms.Label lastNameInitialLabel;
        private System.Windows.Forms.TextBox lastNameInitialTextBox;
        private System.Windows.Forms.RadioButton freshmanButton;
        private System.Windows.Forms.Label classStandingLabel;
        private System.Windows.Forms.RadioButton sophomoreButton;
        private System.Windows.Forms.RadioButton juniorButton;
        private System.Windows.Forms.RadioButton seniorButton;
        private System.Windows.Forms.Button registartionButton;
    }
}

