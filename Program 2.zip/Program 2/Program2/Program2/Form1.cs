﻿/* Grading ID:  A1469
Program 2
This program will gather the first letter of the user's last name from a textbox and the user's 
class standing classification using a set or radiobutton controls. 
When the user submits their class standing and last name letter, the earliest date and time will be shown.
Due 10-19-17
CIS 199-01*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void registartionButton_Click(object sender, EventArgs e)
        {
            //Variables

            char initialOfLastName; // Initial of users last name

            //Constants

            const char A = 'A';
            const char D = 'D';
            const char E = 'E';
            const char I = 'I';
            const char J = 'J';
            const char O = 'O';
            const char P = 'P';
            const char S = 'S';
            const char T = 'T';
            const char Z = 'Z';
            const char L = 'L';
            const char V = 'V';
            const char M = 'M';
            const char Q = 'Q';
            const char R = 'R';
            const char F = 'F';
            const char C = 'C';
            const char W = 'W';
            const char B = 'B';
            const char G = 'G';
            const char z = 'z';
            const char t = 't';
            const char s = 's';
            const char p = 'p';
            
            const char o = 'o';
            
            const char d = 'd';
            
            const char l = 'l';
            const char v = 'v';
           
            const char q = 'q';
            const char r = 'r';
            const char f = 'f';
            
            const char w = 'w';
            const char b = 'b';
            
            const char i = 'i';
            const string timeSlot1 = "8:30"; //  registation time 1
            const string timeSlot2 = "10:00"; // registration time 2
            const string timeSlot3 = "11:30"; // registration time 3
            const string timeSlot4 = "2:00"; // registration time 4
            const string timeSlot5 = "4:00"; // registration time 5
            const string daySlot1 = "November 3rd"; // registation day 1
            const string daySlot2 = "November 6th"; // registration day 2
            const string daySlot3 = "November 7th"; // registration day 3
            const string daySlot4 = "November 8th"; // registration day 4
            const string daySlot5 = "November 9th"; // registration day 5
            const string daySlot6 = "November 10th"; // registration day 6


            {
                if (seniorButton.Checked)  // if user is a senior
                {
                    string lastName = lastNameInitialTextBox.Text; //declares input from user as string variable lastname
                    if (char.IsLetter(lastName[0])) //checks to see if input from user is a letter
                    {
                        //char.ToUpper(initialOfLastName);
                        initialOfLastName = lastName[0];
                        if ((char.ToUpper(initialOfLastName) <= Z || char.ToLower(initialOfLastName) <= z) && char.ToUpper(initialOfLastName) >= T || char.ToLower(initialOfLastName) >= t) //if intial is between T and Z
                        {
                            MessageBox.Show(daySlot1 + " " + timeSlot1); // shows November 3rd 8:30 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= D))  //if intial is between A and D
                        {
                            MessageBox.Show(daySlot1 + " " + timeSlot2); //shows November 3rd 10:00 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= I || char.ToLower(initialOfLastName) <= i) && char.ToUpper(initialOfLastName) >= E)  //if intial is between E and I
                        {
                            MessageBox.Show(daySlot1 + " " + timeSlot3);  // shows November 3rd 11:30 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= O || char.ToLower(initialOfLastName) <= o) && char.ToUpper(initialOfLastName) >= J) //if intial is between J and O
                        {
                            MessageBox.Show(daySlot1 + " " + timeSlot4);  //shows November 3rd 2:00 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= S || char.ToLower(initialOfLastName) <= s) && char.ToUpper(initialOfLastName) >= P) //if intial is between P and S
                        {
                            MessageBox.Show(daySlot1 + " " + timeSlot5); //Message box displays November 3rd 4:00 as the users registration date and time
                        }

                    }
                    else
                    {
                        MessageBox.Show("Invalid letter entered!"); //tells user invalid initial has been entered
                    }
                }
                else if (juniorButton.Checked) // if user credit hours are greater or equal 60 credits, they are juniors.
                {
                    string lastName = lastNameInitialTextBox.Text; //declares input from user as string variable lastname
                    if (char.IsLetter(lastName[0])) //checks to see if input from user is a letter
                    {
                        //char.ToUpper(initialOfLastName);
                        initialOfLastName = lastName[0];
                        if ((char.ToUpper(initialOfLastName) <= Z || char.ToLower(initialOfLastName) <= z) && char.ToUpper(initialOfLastName) >= T || char.ToLower(initialOfLastName) >= t) //if intial is between T and Z
                        {
                            MessageBox.Show(daySlot2 + " " + timeSlot1); //shows November 6th 8:30 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= D || char.ToLower(initialOfLastName) <= d) && char.ToUpper(initialOfLastName) >= A) //if intial is between A and D

                        {
                            MessageBox.Show(daySlot2 + " " + timeSlot2); //shows November 6th 10:00 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= I || char.ToLower(initialOfLastName) <= i) && char.ToUpper(initialOfLastName) >= E) //if intial is between E and I
                        {
                            MessageBox.Show(daySlot2 + " " + timeSlot3); //shows November 6th 11:30 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= O || char.ToLower(initialOfLastName) <= o) && char.ToUpper(initialOfLastName) >= J)   //if intial is between J and O
                        {
                            MessageBox.Show(daySlot2 + " " + timeSlot4); //shows November 6th 2:00 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= S || char.ToLower(initialOfLastName) <= s) && char.ToUpper(initialOfLastName) >= P || char.ToLower(initialOfLastName) >= p)  //if intial is between P and S
                        {
                            MessageBox.Show(daySlot2 + " " + timeSlot5); //shows November 6th 4:00 as the users registration date and time
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid letter entered!"); //displays message box telling user invalid initial has been entered.
                    }
                }
                else if (sophomoreButton.Checked)// if user credit hours are equal to or more than 30 credits, they are sophomores.
                {
                    string lastName = lastNameInitialTextBox.Text; //declares input from user as string variable lastname
                    if (char.IsLetter(lastName[0])) //checks to see if input from user is a letter
                    {
                        //char.ToUpper(initialOfLastName);
                        initialOfLastName = lastName[0];
                        if ((char.ToUpper(initialOfLastName) <= V || char.ToLower(initialOfLastName) <= v) && char.ToUpper(initialOfLastName) >= T) //if intial is between t and v
                        {
                            MessageBox.Show(daySlot3 + " " + timeSlot1); // shows November 7th 8:30 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= Z|| char.ToLower(initialOfLastName) <= z) && char.ToUpper(initialOfLastName) >= W || char.ToLower(initialOfLastName) >= w) //if intial is between w and z
                        {
                            MessageBox.Show(daySlot3 + " " + timeSlot2); //shows November 7th 10:00 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= B || char.ToLower(initialOfLastName) <= b) && char.ToUpper(initialOfLastName) >= A) //if intial is between a and b
                        {
                            MessageBox.Show(daySlot3 + " " + timeSlot3); // shows November 7th 11:30 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= D || char.ToLower(initialOfLastName) <= d) && char.ToUpper(initialOfLastName) >= C) //if intial is between c and d
                        {
                            MessageBox.Show(daySlot3 + " " + timeSlot4); //shows November 7th 2:00 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= F || char.ToLower(initialOfLastName) <= f) && char.ToUpper(initialOfLastName) >= E) //if intial is between e and f
                        {
                            MessageBox.Show(daySlot3 + " " + timeSlot5); //shows November 7th 4:00 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= I || char.ToLower(initialOfLastName) <= i) && char.ToUpper(initialOfLastName) >= G) //if intial is between g and i
                        {
                            MessageBox.Show(daySlot4 + " " + timeSlot1); // shows November 8th 8:30 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= L|| char.ToLower(initialOfLastName) <= l) && char.ToUpper(initialOfLastName) >= J) //if intial is between j and l
                        {
                            MessageBox.Show(daySlot4 + " " + timeSlot2); //shows November 8th 10:00 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= O || char.ToLower(initialOfLastName) <= o) && char.ToUpper(initialOfLastName) >= M) //if intial is between m and o
                        {
                            MessageBox.Show(daySlot4 + " " + timeSlot3); //shows November 8th 11:30 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= Q || char.ToLower(initialOfLastName) <= q) && char.ToUpper(initialOfLastName) >= P) //if intial is between p and q
                        {
                            MessageBox.Show(daySlot4 + " " + timeSlot4); //shows November 8th 2:00 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= S || char.ToLower(initialOfLastName) <= s) && char.ToUpper(initialOfLastName) >= R || char.ToLower(initialOfLastName) >= r) //if intial is between r and s
                        {
                            MessageBox.Show(daySlot4 + " " + timeSlot5); //shows November 8th 4:00 as the users registration date and time
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid letter entered!"); //displays message box telling user invalid initial has been entered.
                    }
                }
                else if (freshmanButton.Checked) //if user credit hours are less than 30 credits, they are freshmen.
                {
                    string lastName = lastNameInitialTextBox.Text; //declares input from user as string variable lastname
                    if (char.IsLetter(lastName[0]))
                    {
                        //char.ToUpper(initialOfLastName);
                        initialOfLastName = lastName[0];

                        if ((char.ToUpper(initialOfLastName) <= V || char.ToLower(initialOfLastName) <= v) && char.ToUpper(initialOfLastName) >= T) //if intial is between t and v
                        {
                            MessageBox.Show(daySlot5 + " " + timeSlot1); //shows November 9th 8:30 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= Z || char.ToLower(initialOfLastName) <= z) && char.ToUpper(initialOfLastName) >= W) //if intial is between w and z
                        {
                            MessageBox.Show(daySlot5 + " " + timeSlot2); //shows November 9th 10:00 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= B || char.ToLower(initialOfLastName) <= b) && char.ToUpper(initialOfLastName) >= A) //if intial is between a and b
                        {
                            MessageBox.Show(daySlot5 + " " + timeSlot3); //shows November 9th 11:30 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= D || char.ToLower(initialOfLastName) <= d) && char.ToUpper(initialOfLastName) >= C) //if intial is between c and d
                        {
                            MessageBox.Show(daySlot5 + " " + timeSlot4); //shows November 9th 2:00 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= F || char.ToLower(initialOfLastName) <= f) && char.ToUpper(initialOfLastName) >= E) //if intial is between e and f
                        {
                            MessageBox.Show(daySlot5 + " " + timeSlot5); //shows November 9th 4:00 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= I || char.ToLower(initialOfLastName) <= i) && char.ToUpper(initialOfLastName) >= G) //if intial is between g and i
                        {
                            MessageBox.Show(daySlot6 + " " + timeSlot1); //shows November 10th 8:30 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= L|| char.ToLower(initialOfLastName) <= l) && char.ToUpper(initialOfLastName) >= J) //if intial is between j and l
                        {
                            MessageBox.Show(daySlot6 + " " + timeSlot2);//shows November 10th 10:00 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= O || char.ToLower(initialOfLastName) <= o) && char.ToUpper(initialOfLastName) >= M) //if intial is between m and o
                        {
                            MessageBox.Show(daySlot6 + " " + timeSlot3); //shows November 10th 11:30 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= Q || char.ToLower(initialOfLastName) <= q) && char.ToUpper(initialOfLastName) >= P) //if intial is between p and q
                        {
                            MessageBox.Show(daySlot6 + " " + timeSlot4); //shows Novemebr 10th 2:00 as the users registration date and time
                        }
                        else if ((char.ToUpper(initialOfLastName) <= S || char.ToLower(initialOfLastName) <= s) && char.ToUpper(initialOfLastName) >= R|| char.ToLower(initialOfLastName) >= r) //if intial is between r and s
                        {
                            MessageBox.Show(daySlot6 + " " + timeSlot5); //shows November 10th 4:00 as the users registration date and time
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid letter entered!");//displays message box telling user invalid initial has been entered.
                    }
                }

            } }
            
            }


        }

        
        

        
    

