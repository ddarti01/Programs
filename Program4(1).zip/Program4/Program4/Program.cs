﻿// A1469
// Program 4
// December 5 2017
// CIS 199- 01
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Program_4
{
    class Program
    {

        static void Main(string[] args)
        { // create derived class object

            LibraryBook book1 = new LibraryBook("Double Fudge", "Judy B.Blume", "Berkley", 2014, "LB28");
            LibraryBook book2 = new LibraryBook("Slam", "Walter Dean.Myers", "Scholastic Paperbacks", 2008, "KY29");
            LibraryBook book3 = new LibraryBook("Where Wild Things Are", "Maurice Sendak", "Harper & Row", 1963, "LB30");
            LibraryBook book4 = new LibraryBook("The Adventures of Captain Underpants", "Dav Pilkey", "Scholastic", 1997, "OG31");
            LibraryBook book5 = new LibraryBook("Frankenstein", " Mary Shelley", " Dover Publications", 1994, "LB32");

            // create 5 element Librarybook array
            LibraryBook[] books = new LibraryBook[5];

            books[0] = book1;
            books[1] = book2;
            books[2] = book3;
            books[3] = book4;
            books[4] = book5;

            ShowBook(books);

            //Changed publisher for book arrarys, 2 books must be checked out
            books[0].Publisher = "Hachette Book Group";
            books[1].Publisher = "HarperCollins";
            books[2].Publisher = "Penguin";
            books[3].CheckOut();
            books[4].CheckOut();

            ShowBook(books); //call ShowBook method to display info about books

            books[3].ReturnToShelf();
            books[4].ReturnToShelf();


            ShowBook(books); // call ShowBook method to display info about books





        }

        //precondition: none
        //postcondition several book objects created and output
        public static void ShowBook(LibraryBook[] bookarray)
        {
            foreach (LibraryBook book in bookarray)
            {
                Console.WriteLine(book.ToString());
            }

        }


    }
}
