﻿// A1469
// Program 4
// December 5 2017
// CIS 199- 01

// file: LibraryBook.cs
// this file creates a class that constructs a book with a title, author, publisher, copyright year, callnumber
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    public class LibraryBook
    {

        int _copyrightyear;

        //Constructor
        // precondition none
        //postcondition the LibraryBook object has been initialized with the specifeid tittle, author, publisher, copyrightyear and callnumber
        public LibraryBook(string title, string author, string publisher, int copyrightyear, string callnumber)
        {
            //Use properties to set in case invalid data sent
            _copyrightyear = copyrightyear; // book copyright year
            Title = title; // book title
            Author = author; // book author
            Publisher = publisher; // book publisher
            CallNumber = callnumber; // book call number
        }

        //backing field
        private bool checkedoutstatus = false; // checkedout status = not checked out


        //preconditon: none
        //postconditon: The title has been returned
        public string Title { get; set; }

        //preconditon: none
        //postconditon: The author has been returned
        public string Author { get; set; }

        //preconditon: none
        //postconditon: The publisher has been returned
        public string Publisher { get; set; }

        //preconditon: none
        //postconditon: The call number has been returned
        public string CallNumber { get; set; }

        public int Copyrightyear
        {
            //precondition: none
            //postcondition: copyright year is returned
            get
            {
                return _copyrightyear;
            }

            //precondition: value >= 0
            //postcondiiton: the copyright year has been set to a specified value
            set
            {
                if (value >= 0)
                    _copyrightyear = value;
                else
                    _copyrightyear = 2017;
            }

        }

        public void CheckOut()
        {
            //precondition: none
            //postcondition: changes book status to reflect if it's been checked out
            checkedoutstatus = true;

        }

        public void ReturnToShelf()
        {
            //precondition: book must be already checked out
            //postcondition: change the books checked out status to reflect that the book has been returned and isn't checked out no more
            checkedoutstatus = false;
        }

        public bool IsCheckedOut()
        {
            //precondition: must have a book
            //postcondition: returns a true value if book is checked out and returns a false value when the book is not out
            if (checkedoutstatus == true)
            {
                return checkedoutstatus;
            }
            else
            {
                return false;
            }
        }
        //precondition: none
        //postcondition: a string is returned representing the details of the new book
        public override string ToString()
        {
            string text = "Title: " + Title + Environment.NewLine + "Author: " + Author + Environment.NewLine + "Publisher: " + Publisher + Environment.NewLine + "Copyright Year: " + Copyrightyear + Environment.NewLine + "Call Number: " + CallNumber + Environment.NewLine + "Checked Out Status: " + checkedoutstatus;
            return text;
        }
    }
}
